model package
=============

Submodules
----------

model.AbstractAPI module
------------------------

.. automodule:: model.AbstractAPI
    :members:
    :undoc-members:
    :show-inheritance:

model.offlineAPI module
-----------------------

.. automodule:: model.offlineAPI
    :members:
    :undoc-members:
    :show-inheritance:

model.onlineAPI module
----------------------

.. automodule:: model.onlineAPI
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: model
    :members:
    :undoc-members:
    :show-inheritance:
